// Program izracuna vsoto x + y in izpise na zaslon
public class VsotaXY {

  public static void main(String args[]) {
    int x = 5;
    int y = 13;

    // za izpis uporabimo metodo printf
    System.out.printf("%d + %d = %d\n", x, y, x + y);
  }
}
