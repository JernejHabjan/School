Za prenos repozitorija uporabite ukaz 

    git clone https://github.com/FRI-TD/P2-201516.git

Za prenos vseh datotek projekta (v eni ZIP datoteki) uporabite gumb "Download ZIP".