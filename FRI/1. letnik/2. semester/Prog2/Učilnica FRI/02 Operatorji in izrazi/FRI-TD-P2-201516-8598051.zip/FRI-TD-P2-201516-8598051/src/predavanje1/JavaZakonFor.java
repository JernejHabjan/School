// Program 5x izpise besedilo Java je zakon!
public class JavaZakonFor {
	public static void main(String args[]) {
		int i;
		for(i=0; i<5; i=i+1) {
			System.out.println("Java je zakon!");
		}
	}
}