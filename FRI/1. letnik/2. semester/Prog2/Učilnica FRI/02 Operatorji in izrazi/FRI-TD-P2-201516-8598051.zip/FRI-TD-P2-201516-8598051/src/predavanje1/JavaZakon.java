// Program 5x izpise besedilo Java je zakon!
public class JavaZakon {
	public static void main(String args[]) {
		System.out.println("Java je zakon!");
		System.out.println("Java je zakon!");
		System.out.println("Java je zakon!");
		System.out.println("Java je zakon!");
		System.out.println("Java je zakon!");
	}
}