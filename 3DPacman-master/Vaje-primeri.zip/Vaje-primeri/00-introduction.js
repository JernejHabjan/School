var canvas; // referenca na platno na katerega bomo risali
var gl; // referenca na 3D kontekst na katerega bomo izrisovali

function start(){ // to funkcijo klicemo na zacetki u html
	canvas = document.getElementById('glcanvas');

	gl = initGL(canvas);

	if(gl){ // v primeru da se GL-kontekst ustvari zacnemo risat
		gl.clearColor(0.0, 0.0, 0.0, 1.0); // kontekst pobarvamo črno RGB+prosojnost
		gl.clearDepth(1.0); // globinske vrednosti vseh pikslov nastavimo na 1
		gl.enable(gl.DEPTH_TEST); //vkljucmo globinsko testiraje
		gl.depthFunc(gl.LEQUAL);
		gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); //pobrišemo barvni in globinski medpomnilnik
	}
}

function initGL(canvas) {
	gl = null;

	try{ // pridobimo novo instanco gl konteksta
		gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");

	}catch(e) {}
	

	if(!gl){
		alert("Unable to initialise WebGL browser ne podpira WebGL");
	}
	return gl; // vrnemo WebGL da ba bomo imeli na razzpologo v funkciji start
}