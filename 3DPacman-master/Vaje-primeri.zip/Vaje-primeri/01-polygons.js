var canvas; // referenca na platno na katerega bomo risali
var gl; // referenca na 3D kontekst na katerega bomo izrisovali
var shaderProgram; //referenca na program ki bo izracunal senčenje

var triangleVertexPositionBuffer; //predpomnilnik za polozaj trikontika ki se bo zrosvov
var squareVertexPositionBuffer; //podatki za vozlisca za kvadrat

var mvMatrix = mat4.create();
var pMatrix = mat4.create();  //projekcijska matrika
//knjiznica imenovana ""./glMatrix-0.9.5.min.js"" neki mors met v mapi



function initGL(canvas) {
	var gl = null;
	try{ // pridobimo novo instanco gl konteksta
		gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
		//velikost okna v svet sko prilagodili na risalno površino
		gl.viewportWidth = canvas.width;	//canvas=platno
		gl.viewportHeight = canvas.height;	//velikost okna platna->sveta
	}catch(e) {}
	

	if (!gl) {
    	alert("Unable to initialize WebGL. Your browser may not support it.");
  	}
	return gl;// vrnemo WebGL da ba bomo imeli na razzpologo v funkciji start
}

//metoda za pridobivanje sencilnikov
function getShader(gl, id) { //id je id za sencilnika v html torej ali "shader-fs" ali "shader-vs"
	var shaderScript = document.getElementById(id);
	
	if (!shaderScript) { // ce nismo prebrali kode sencilnika
    	return null;
	}

	var shaderSource = "";
	var currentChild = shaderScript.firstChild;
	while (currentChild) {	//dokler obstaja pogledamo vrsto oglisca in ce ustreza konstanti 3-je source ga bomo priprenjali nasi prog. kodi
		if (currentChild.nodeType == 3) {
        	shaderSource += currentChild.textContent;
    	}
		currentChild = currentChild.nextSibling;
	}

	//kaksnega tipa je nas sencilnik
	var shader;
	 if (shaderScript.type == "x-shader/x-fragment") {
		shader = gl.createShader(gl.FRAGMENT_SHADER);
	} 	//prebrali fragment shader
	else if (shaderScript.type == "x-shader/x-vertex") {
		shader = gl.createShader(gl.VERTEX_SHADER);
	}
	else{ //neznan sencilnik
		return null;
	}

	gl.shaderSource(shader, shaderSource);

	//sedaj moramo sencilnik prevest
	gl.compileShader(shader);

	//preverimo ali se je vse skupaj uspesno prevedlo
  	if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    	alert(gl.getShaderInfoLog(shader));
    	return null;
	}

	return shader;
}

function initShaders(){
	//pridobi in prededi oba sencilnika
	var fragmentShader = getShader(gl, "shader-fs");
  	var vertexShader = getShader(gl, "shader-vs");


	shaderProgram = gl.createProgram();//program
	//programu pripnemo sencilnike
 	gl.attachShader(shaderProgram, vertexShader);
	gl.attachShader(shaderProgram, fragmentShader);
	//zdej jih mormo se zlinkat
	gl.linkProgram(shaderProgram);

	//ali je proslo do napake pri povezovanju
	if (!gl.getProgramParameter(shaderProgram, gl.LINK_STATUS)) {
    	alert("Unable to initialize the shader program. prislo je do napake (104-vrstica) - Unable to initialise the shader program");
	}
	
	gl.useProgram(shaderProgram); // ce ni prislo do napake lahko sedaj uporabljamo ta program

	shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition"); // prebrali smo v spremenljjivko aVertexPosition 

	//vkljucimo vertex podporo
	gl.enableVertexAttribArray(shaderProgram.vertexPositionAttribute);

	shaderProgram.pMatrixUniform = gl.getUniformLocation(shaderProgram, "uPMatrix");
	shaderProgram.mvMatrixUniform = gl.getUniformLocation(shaderProgram, "uMVMatrix");
} 


//pomozna metoda ki bo pomoagala pri tem da bomo nastavljali matrike
	// setMatrixUniforms
	//
	// Set the uniform values in shaders for model-view and projection matrix.
	//
function setMatrixUniforms() {
  gl.uniformMatrix4fv(shaderProgram.pMatrixUniform, false, pMatrix);
  gl.uniformMatrix4fv(shaderProgram.mvMatrixUniform, false, mvMatrix);
}


//inicializacija medpomnilnikov. tu bomo mel shranjene podatke o nasi geometriji
//napolnila bo medpomnilnike z podatki trikotnika in stirikotnika
	// initBuffers
	// Initialize the buffers we'll need. For this demo, we just have
	// two objects -- a simple two-dimensional triangle and square.
function initBuffers() {
  // TRIKOTNIK /  TRIANGLE
  // Create a buffer for the triangle's vertices.
  triangleVertexPositionBuffer = gl.createBuffer();

  // Select the triangleVertexPositionBuffer as the one to apply vertex
  // operations to from here out.
  gl.bindBuffer(gl.ARRAY_BUFFER, triangleVertexPositionBuffer);//povezemo ga z glavnim pomnilnikom
  // kordinati 3-eh vozlisc. !!! definiramo jih v obratni smeri urinega kazalca
  var vertices = [ 
     0.0,  1.0,  0.0,
    -1.0, -1.0,  0.0,
     1.0, -1.0,  0.0
  ];

  // prepisemo podatke 
  // Pass the list of vertices into WebGL to build the shape. We
  // do this by creating a Float32Array from the JavaScript array,
  // then use it to fill the current vertex buffer.
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
  triangleVertexPositionBuffer.itemSize = 3; //koliko je velikost medpomnilnika za vsako vozlisce 3 floute
  triangleVertexPositionBuffer.numItems = 3; // koliko je vseh elementov - mamo 3 vozlisca ker mamo trikotnik

  //----------------------

  // STRIKIKOTNI SQUARE
  // Create a buffer for the square's vertices.
  squareVertexPositionBuffer = gl.createBuffer();
  
  // Select the squareVertexPositionBuffer as the one to apply vertex
  // operations to from here out.
  gl.bindBuffer(gl.ARRAY_BUFFER, squareVertexPositionBuffer);
  
  // Now create an array of vertices for the square. Note that the Z
  // coordinate is always 0 here.
  vertices = [
     1.0,  1.0,  0.0,
    -1.0,  1.0,  0.0,
     1.0, -1.0,  0.0,
    -1.0, -1.0,  0.0
  ];
  
  // Now pass the list of vertices into WebGL to build the shape. We
  // do this by creating a Float32Array from the JavaScript array,
  // then use it to fill the current vertex buffer.
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);
  squareVertexPositionBuffer.itemSize = 3;
  squareVertexPositionBuffer.numItems = 4;
}


// DEFINIRAMO SE IZRIS
	// drawScene
	// Draw the scene.
function drawScene() {
  //kaksno je nase okno v svet
  // set the rendering environment to full canvas size
  gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);

  //pobrisemo globino in barvo na platnu
  // Clear the canvas before we start drawing on it.
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  
  //definiramo novo matriko perspektvno 
  //v sceno bomo gledali s perspetkitno prspetcijo s kotom 45 stopinj
  // blizinsko in daljno rezalno povrsino/kolk je najblizji oddaljen in kolk je najbolj oddaljen element
  // rezultat shranimo v pMatrix
	  // Establish the perspective with which we want to view the
	  // scene. Our field of view is 45 degrees, with a width/height
	  // ratio, and we only want to see objects between 0.1 units
	  // and 100 units away from the camera.
	  mat4.perspective(45, gl.viewportWidth / gl.viewportHeight, 0.1, 100.0, pMatrix);
  

  // Set the drawing position to the "identity" point, which is
  // the center of the scene.
  mat4.identity(mvMatrix);
  

  //kje bomo izrisali trikotnik in kje 4kotnik
  	// TRIANGLE:
  	// Now move the drawing position a bit to where we want to start
  	// drawing the triangle.
  mat4.translate(mvMatrix, [-1.5, 0.0, -7.0]); 	// 1.5 v levo, 0 visine, globina na -7.0
  
  // izrisemo trikotnik
  	// Draw the triangle by binding the array buffer to the square's vertices
  	// array, setting attributes, and pushing it to GL.
  gl.bindBuffer(gl.ARRAY_BUFFER, triangleVertexPositionBuffer);
  gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, triangleVertexPositionBuffer.itemSize, gl.FLOAT, false, 0, 0);
  setMatrixUniforms();
  gl.drawArrays(gl.TRIANGLES, 0, triangleVertexPositionBuffer.numItems);



  // SQUARE:
  // Now move the drawing position a bit to where we want to start
  // drawing the square.
  mat4.translate(mvMatrix, [3.0, 0.0, 0.0]);	//premaknemo se za 3 v desno

  // Draw the square by binding the array buffer to the square's vertices
  // array, setting attributes, and pushing it to GL.
  gl.bindBuffer(gl.ARRAY_BUFFER, squareVertexPositionBuffer);
  gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, squareVertexPositionBuffer.itemSize, gl.FLOAT, false, 0, 0);
  setMatrixUniforms();
  gl.drawArrays(gl.TRIANGLE_STRIP, 0, squareVertexPositionBuffer.numItems);
}






function start(){ // to funkcijo klicemo na zacetki u html
	canvas = document.getElementById('glcanvas');

	gl = initGL(canvas);

	if(gl){ // v primeru da se GL-kontekst ustvari zacnemo risat
		gl.clearColor(0.0, 0.0, 0.0, 1.0); // kontekst pobarvamo črno RGB+prosojnost
		gl.clearDepth(1.0); // globinske vrednosti vseh pikslov nastavimo na 1
		gl.enable(gl.DEPTH_TEST); //vkljucmo globinsko testiraje
		gl.depthFunc(gl.LEQUAL);
		//gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); //pobrišemo barvni in globinski medpomnilnik
		initShaders();
		initBuffers();

		setInterval(drawScene, 15); //risi na 15mili sekund
	}
}















